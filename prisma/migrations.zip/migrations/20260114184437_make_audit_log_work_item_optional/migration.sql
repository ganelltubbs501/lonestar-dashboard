-- AlterTable
ALTER TABLE "AuditLog" ALTER COLUMN "workItemId" DROP NOT NULL;
